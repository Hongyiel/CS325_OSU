#This is for Readme file on HW1
# OSU CS325 Hongyiel Suh

# How to Compile ?
  <#> input on the command line below command
  <1> python3.7 [program_file_name]

# what including ?
program consist of HW1_3 folder and HW1_4 folder

  - HW1_3 consist of
      - data.txt (example file from document)
      - insert.txt
      - merge.txt
      - insertsort.py
          - insertion sort algorithm will run on this program
      - mergesort.py
          - merge sort algorithm will run on this program

  - HW1_4 consist of
      - insertTime.py
          - it will compare insert sort Time
      - mergeTime.py
          - it will compare merge sort Time
      - plot#.py (They are all graph files)
